import java.util.Scanner;
public class Deliverable1 {

	public static void main(String[] args) {
		String result;
		String transportation = null;
		String destination = null;
		String vacationType;
		int groupSize;
		Scanner vacation = new Scanner(System.in);
		System.out.printf("What kind of trip would you like to go on, musical,\r\n" + 
				"tropical, or adventurous? ");
		vacationType = vacation.next();
		
		Scanner group = new Scanner(System.in);
		System.out.printf("How many are in your group? ");
		groupSize = group.nextInt();
		
	switch(vacationType) {
	case "musical": 
	destination = "New Orleans";
		break;
	case "tropical":
	    destination = "Beach vacation in Mexico";
	    break;
	case "adventurous":
		destination = "Whitewater Rafting the Grand Canyon";
		break;
	}
	switch(groupSize) {
	case 1:
		transportation = "first class";
		break;
	case 2:
		transportation = "first class";
		break;
	case 3:
		transportation = "helicopter";
		break;
	case 4:
		transportation = "helicopter";
		break;
	case 5:
		transportation = "helicopter";
		break;
	case 6: 
		if (groupSize >= 6) {
			transportation = "charter flight";
			break;
		}
	}
	result = "Since you�re a group of " + groupSize + " going on a " + vacationType + ", you \r\n" +
			"should take a " + transportation + " to " + destination + "!";
		
	System.out.printf(result);
}
}